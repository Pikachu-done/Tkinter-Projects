# ------- 1.. ----------

# myDict = {
#     "Slow": "Tortoise",
#     "Tanish": "Running",
#     "Marks": [1,2,3],
#     "anotherDict": {"Player": "Tanish"}
# }

# print(myDict["Slow"])
# print(myDict["Marks"])
# print(myDict["Tanish"])
# myDict["Tanish"] = "Jogging"
# print(myDict["Tanish"])
# print(myDict["anotherDict"]["Player"])




# ---------- 2.. --------- (Methods)
# myDict = {
#     "Slow": "Tortoise",
#     "Tanish": "Running",
#     "Marks": [1,2,3],
#     "anotherDict": {"Player": "Tanish"}
# }

# print(list(myDict.keys()))
# print(list(myDict.values()))
# print(list(myDict.items()))

# print(myDict)
# updateDict = {
#     "Childish" : "Friend"
# }
# myDict.update(updateDict)
# print(myDict)

# print(myDict.get("Childishi"))      #Throws None if value isn't der..
# print(myDict["Childishi"])      #Throws an Error if value isn't der..



# Questions.. Answers..
# myDict = {
#     "Pankha": "Fan",
#     "Istri": "Iron",
#     "Kapda": "Cloth"
# }

# print("Options are: ", myDict.keys())
# a = input("Enter your Hindi Word:\n")
# print("The meaning of your word is:", myDict.get(a))


# Questions.. Answers..
favLang = {}
a = input("Enter Your favourite Language:\n")
b = input("Enter Your favourite Language:\n")
c = input("Enter Your favourite Language:\n")
d = input("Enter Your favourite Language:\n")

favLang["Kashyap"] = a
favLang["Aryan"] = b
favLang["Nandu"] =c
favLang["Mrun"] = d

print(favLang)