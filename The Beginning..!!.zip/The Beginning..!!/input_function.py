a = input("Enter your name: ")
a = int(a) #Convert a to an Integer.
print(type(a))

