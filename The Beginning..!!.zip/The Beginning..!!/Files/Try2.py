def greet(name):
    print(f"Good Morning, {name}")
    
# print(__name__)
if __name__ == "__main__":
    n = input("Enter the Name: ")
    greet(n)