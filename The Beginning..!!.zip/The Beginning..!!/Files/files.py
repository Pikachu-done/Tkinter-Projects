1. #  Reading the File
# f = open("The Beginning..!!\Files\sample.txt", "r")
# data = f.read(6)
# print(data)
# f.close()


2. # Writing a file
# f = open("The Beginning..!!\Files\\another.txt", "w")
# f.write("This is the data we were finding")
# f.close()

3. # Appending
# f = open("The Beginning..!!\Files\\another.txt", "a")
# f.write(" I was appending")
# f.close()


4. #with statement
# with open("The Beginning..!!\Files\\another.txt", "r") as f:
#     a = f.read()
# print(a)

# with open("The Beginning..!!\Files\\another.txt", "w") as f:
#     a = f.write("Hello World")
# print(a)


