# i = 1
# while i<51:
#     print("Yes " + str(i))
#     i = i + 1


# i = 0

# while i < 5:
#     print("tanish")
#     i += 1

# fruits = ["Banana", "Mangoes", "Apple", "Chikoo"]
# i = 0
# while i<len(fruits):
#     print(fruits[i])
#     i = i + 1

# Marks = [
#     "Tanish" , 90,
#     "Kashyap" ,  89,
#     "Nandu" , 89
# ]

# i = 0
# while i<len(Marks):
#     print(Marks[i])
#     i = i + 1