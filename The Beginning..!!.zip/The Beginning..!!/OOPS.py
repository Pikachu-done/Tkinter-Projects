
# class RailwayForm:
#     formType = "RailwayForm"
#     def printData(self):
#         print(f"Name is {self.name}")
#         print(f"Train is {self.train}")

# tanishsApplication = RailwayForm()
# tanishsApplication.name = "Tanish"
# tanishsApplication.train = "Rajdhani Express"
# tanishsApplication.printData()


# class Employee:
#         company = "Google"
#         def getSalary(self):
#             print(f"Salary is {self.salary}")

# tanish = Employee()
# tanish.salary = 100000
# tanish.getSalary()


# class Employee:
#         company = "Google"
#         def getSalary(self, signature):
#             print(f"Salary for the Employee working in {self.company} is {self.salary}\n{signature}")

#         @staticmethod
#         def greet():
#             print("Good Morning, Sir")

# tanish = Employee()
# tanish.salary = 100000
# tanish.getSalary("Thank You!")
# tanish.greet()
# print(tanish.company)



class Employee:
        company = "Google"

        def __init__(self, name, salary, subunit):
            self.name = name
            self.salary = salary
            self.subinit = subunit
            print("A self is Created!")
            
        def getDetails(self):
            print(f"The name of the Employee is {self.name}")
            print(f"The Salary of the {self.name} is {self.salary}")
            print(f"The Subunit of the {self.name} is {self.subinit}")

        def getSalary(self, signature):
            print(f"Salary for the Employee working in {self.company} is {self.salary}\n{signature}")

        @staticmethod
        def greet():
            print("Good Morning, Sir")

        @staticmethod
        def time():
            print("The time is 9 AM in the Morning")

tanish = Employee("Tanish", 100, "Youtube")
tanish.getDetails()