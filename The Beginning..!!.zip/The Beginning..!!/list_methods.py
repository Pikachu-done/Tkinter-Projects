l1 = [1,34,32,65,45,77,63,12]
# l1.sort()
# l1.reverse()
# l1.append(21)
# l1.insert(0, 22)  #(index, object)
# l1.pop(3)
l1.remove(12)

print(l1)