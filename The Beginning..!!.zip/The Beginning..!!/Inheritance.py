1. # Single Inheritance
# class Employee:
#     company = "Google"

#     def showDetails(self):
#         print("This is an Employee")

# class Programmer(Employee):
#     language = "Python"
#     company = "Youtube"

#     def getLanguage(self):
#         print(f"The langauge is {self.language}")

#     def showDetails(self):
#         print("This is an Programmer")
    
# e = Employee()
# e.showDetails()
# p = Programmer()
# p.showDetails()
# print(p.company)
# print(e.company)


2. # Multiple Inheritance
# class Employee:
#     company = 'Visa'
#     eCode = 323

# class Freelancer:
#     company = "Fiverr"
#     level = 0

#     def upgradeLevel(self):
#         self.level = self.level + 1

# class Programmer(Employee, Freelancer):
#     name = "Kashyap"

# p = Programmer()
# p.upgradeLevel()
# print(p.level)
# print(p.company)


3. # Multilevel Inheritance
# class Person:
#     country = "India"

#     def takeBreak(self):
#         print("I am breathing")
    
# class Employee(Person):
#     company = "Ferrari"

#     def getSalary(self):
#         print(f"Salary is {self.salary}")

#     def takeBreak(self):
#         print("I am an Employee that's why I am Breathing")

# class Programmer(Employee):
#     company = "Yahoo"

#     def getSalary(self):
#         print(f"No Salary to Programmers")

# p = Person()
# p.takeBreak()

# e = Employee()
# e.takeBreak()

# pr = Programmer()
# pr.takeBreak()

4. # Super
# class Person:
#     country = "India"  

#     def __init__(self):
#         print("Initializing Person...\n")

#     def takeBreak(self):
#         print("I am breathing")
    
# class Employee(Person):
#     company = "Ferrari"

#     def __init__(self):
#         super().__init__()
#         print("Initializing Employee...\n")

#     def getSalary(self):
#         print(f"Salary is {self.salary}")

#     def takeBreak(self):
#         super().takeBreak()
#         print("I am an Employee that's why I am Breathing")

# class Programmer(Employee):
#     company = "Yahoo"

#     def __init__(self):
        # super().__init__()
    #     print("Initializing Programmer...\n")

    # def getSalary(self):
    #     print(f"No Salary to Programmers")

    # def takeBreak(self):
    #     super().takeBreak()
    #     print("I am an Programmer that's why I am Breathing")

# p = Person()
# p.takeBreak()

# e = Employee()
# e.takeBreak()

# pr = Programmer()
# pr.takeBreak()



5. # Class Methods
# class Employee:
#     company = "Camel"
#     salary = 200
#     location = "Dholakpur"

    # def changeSalary(self, sal):
    #     self.__class__.salary = sal
        
#     @classmethod
#     def changeSalary(cls, sal):
#         cls.salary = sal
# e = Employee()
# print(e.salary)
# e.changeSalary(323)
# print(e.salary)
# print(Employee.salary)


6. # Property Method
# class Employee:
#     company = "Yahoo"
#     salary = 4500
#     salaryBonus = 500

#     @property
#     def totalSalary(self):
#         return self.salary + self.salaryBonus

#     @totalSalary.setter
#     def totalSalary(self, val):
#         self.salaryBonus = val - self.salary

# e = Employee()
# print(e.totalSalary)
# e.totalSalary = 4800
# print(e.salary)
# print(e.salaryBonus)
# print(e.totalSalary)


7. # Operator Overloading
class Number:
    def __init__(self, num):
        self.num = num

    def __add__(self, num2):
        print("Lets add")
        return self.num + num2.num

    def __mul__(self, num2):
        print("Lets Multiply")
        return self.num * num2.num
    
n1 = Number(4)
n2 = Number(6)
sum = n1 + n2
print(sum)
mul = n1 * n2
print(mul)
