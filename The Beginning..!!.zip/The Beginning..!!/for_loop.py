# fruits = ["Banana", "Mangoes", "Apple", "Chikoo"]

# for tanish in fruits:
#     print(tanish)



# -- Break Statement --
# for i in range(10):
#     print(i)
#     if i == 5:
#         break
# else:
#     print("Done")



# -- Continue Statement --
# -- Printing Odd Numbers--
# for i in range(10):
#     if i % 2 == 0:
#         continue
#     print(i)

# -- Printing Even Numbers--
# for i in range(10):
#     if i % 2 != 0:
#         continue
#     print(i)


# -- Pass Statement --
# i = 0
# if i<12:
#     pass
# print("Tanish is better")




# -- Printing Tables from Input.. --
# num = int(input("Enter the Number:\n"))
# for it in range(1,11):
#     print(f"{num} X {it} = {it*num}")



# -- name initials--
# l1 = ["Harry", "Sohan", "Sachin", "Rahul"]
# for name in l1:
#     if name.startswith("S"):
#         print(f"Hello {name}")



# -- Finding whether number is prime or not.. -
# num = int(input("Enter the number:\n"))

# for i in range(2, num):
#     if (num%i == 0):
#         print("Not Prime")
#         break
# else:
#     print("Prime")
        


# -- Factorial --
# num = int(input("Enter the number:\n"))

# factorial = 1
# for i in range(1, num+1): 
#     factorial = factorial * i
# print(f"The Factorial of this number is {factorial}")
# print("The Factorial of this number is ", factorial)



# -- Star printing --
# n = 4
# for i in range(4):
#     print("*" * (i+1))



        






