print('''Twinkle Twinkle Little Star,
How I wonder what you are,
Up above to world so high,
Like a Diamond in the Sky.''')