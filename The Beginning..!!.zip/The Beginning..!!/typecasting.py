a = "2323"
a = int(a)
# print(type(a))
print(a + 12)