1. # Global Variables
# a = 43
# def func1():
#     global a
#     print(f"Prints Statement 1: {a}")
#     a = 23
#     print(f"Prints Statement 2: {a}")

# func1()
# print(f"Prints Statement 3: {a}")


2. # Enumerate
# list1 = [1,2,3,True, "Pikachu", 4.4]
# for index, item in enumerate(list1):
#     print(item, index)


3. # List comprehension
a = [1,2,3,4,5,6,7,8,23,45,66]
# b = []

#A method
# for item in a :
#     if item % 2 == 0:
#         b.append(item)
# print(b)

# Another Method
b = [i for i in a if i % 2 == 0]
print(b)

t = [1, 4, 2, 4, 1, 2, 3]
s = {i for i in t}
print(s)








