# import random


# def gameWin(comp, you):
#     if comp == you:
#         return None

#     elif comp == "s":
#         if you == "w":
#             return False
#         elif you == "g":
#             return True

#     elif comp == "w":
#         if you == "g":
#             return False
#         elif you == "s":
#             return True

#     elif comp == "g":
#         if you == "s":
#             return False
#         elif you == "w":
#             return True
        

# print("Comp's Turn: Snake(s), Water(w) or Gun(g)")
# randNo = random.randint(1,3)
# if randNo == 1:
#     comp = "s"
# elif randNo == 2:
#     comp = "w"
# elif randNo == 3:
#     comp = "g"
# you = input("Your's Turn: Snake(s), Water(w) or Gun(g)")

# print(f"Computer Chose {comp}")
# print(f"You Chose {you}")

# a = gameWin(comp, you)
# if a == None:
#     print("The game is a Tie")
# elif a:
#     print("You Win!")
# else:
#     print("You Lose!")




# Rock, paper and scissor game
import random

def gameWin(comp, you):
    if comp == you:
        return None

    elif comp == "r":
        if you == "s":
            return False
        elif you == "p":
            return True

    elif comp == "p":
        if you == "r":
            return False
        elif you == "s":
            return True

    elif comp == "s":
        if you == "p":
            return False
        elif you == "r":
            return True
        

print("Comp's Turn: Rock(s), Paper(w) or scissor(g)")
randNo = random.randint(1,3)
if randNo == 1:
    comp = "ro"
elif randNo == 2:
    comp = "pa"
elif randNo == 3:
    comp = "sc"
you = input("Your's Turn: Rock(s), Paper(w) or Scissor(g)")

print(f"Computer Chose {comp}")
print(f"You Chose {you}")

a = gameWin(comp, you)
if a == None:
    print("The game is a Tie")
elif a:
    print("You Win!")
else:
    print("You Lose!")
    