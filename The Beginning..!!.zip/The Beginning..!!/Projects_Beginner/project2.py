import random
randNumber = random.randint(1, 50 )
userGuess = None
guesses = 0
while userGuess != randNumber:
    userGuess = int(input("Enter your Guess: "))
    guesses += 1
    if userGuess == randNumber:
        print("You Guessed it Right!")
    else:
        if userGuess > randNumber:
                print("You Guessed it Wrong! Enter a Smaller Number")
        else:
                print("You Guessed it Wrong! Enter a Larger Number")

print(f"You Guesses the Number in {guesses} guesses")

with open ("The Beginning..!!\Projects_Beginner\highscore.txt", "r") as f:
    highscore = int(f.read())

if guesses<highscore:
    print("You've just broken the Record of High Score")
    with open ("The Beginning..!!\Projects_Beginner\highscore.txt", "w") as f:
        f.write(str(guesses))
