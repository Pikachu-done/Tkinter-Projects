class Library:

    def __init__(self, listOfBooks):
        self.books = listOfBooks

    def displayAvailableBooks(self):
        print("Books present in this Library are: ")
        for book in self.books:
            print("\t *", book)
    
    def borrowBook(self, bookName):
        if bookName in self.books:
            print(f"You have been issued {bookName}. Please keep it safe.")
            self.books.remove(bookName)
            return True
        else:
            print(f"Sorry. This book has already been issued. Please wait until the book is returned.")
            return False
        
    def returnBook(self, bookName):
        self.books.append(bookName)
        print("Thank you for returning this Book! Hope you enjoyed reading it.")

class Student:
    def __init__(self):
        self.bookList = []
    def requestBook(self):
        self.book = input("Enter the name of the Book you wanna Borrow: ")
        return self.book

    def returnBook(self):
        self.book = input("Enter the name of the Book you wanna Return: ")
        return self.book

if __name__ == "__main__":
    centralLibrary = Library(["Algorithms", "Django", "Clrs", "Python Notes"])
    student = Student()
    # centralLibrary.displayAvailableBooks()
    while(True):
        welcomeMsg = '''==== Welcome to the Central Library ====
        Please select an option:
        1. Listing all the Books.
        2. Request a Book.
        3. Return a Book.
        4. Exit the Library.
        '''
        print(welcomeMsg)

        a = int(input("Enter a Choice: "))
        if a == 1:
            centralLibrary.displayAvailableBooks()
        elif a == 2:
            centralLibrary.borrowBook(student.requestBook())
        elif a == 3:
            centralLibrary.returnBook(student.returnBook())
        elif a == 4:
            print("Thank You for using this Library!")
            exit()
        else:
            print("Invalid Choice!")