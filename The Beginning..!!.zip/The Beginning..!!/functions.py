# def percent(marks):
#     return (sum(marks)/400)*100

# marks1 = [98,78,89,99]
# percentage = percent(marks1)
# print(percentage)


# def average(marks):
#     return (sum(marks)/700)*100

# marks1 = [12, 45, 67, 34, 78, 98, 100]
# average1 = average(marks1)
# print(average1)


# -- Greetings --
# def greet(name):
#     print("Good day " +name)
# greet("tanish")


# -- Adding 2 numbers by functions --
# def mySum(num1, num2):
#     return num1 + num2

# s = mySum(12, 23)
# print(s)


# -- Default arguments --
# def greet(name = "Stranger"):
#     print("Good day " + name)

# greet("Tanish")
# greet()


