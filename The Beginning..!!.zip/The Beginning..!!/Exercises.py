1.  # Finding out the Maximum value

# def maximum(num1, num2, num3):
#     if (num1 > num2):
#         if(num1 > num3):
#             return num1
#         else:
#             return num3
#     else:
#         if(num2 > num3):
#             return num2
#         else:
#             return num3

# print(maximum(92, 53, 43))

2.  # Fahrenheit to Celsius
# def farh(cel):
#     return (cel * (9/5)) + 32
# c = 0
# f = farh(c)
# print(f)

3.  # Preventing print() function to print a new line at the end
# print("Hello" , end=" ")
# print("How" , end=" ")
# print("are" , end=" ")
# print("you?" , end=" ")

4.  # Star pattern
# n = int(input("Enter the number:\n"))
# for i in range(n):
#     print("*" * (n-i))

5.  # Strip and remove at the same time.
# def remove_and_strip(string, word):
#     newStr = string.replace(word, " ")
#     return newStr.strip()
# this = "         Tanish  is a good boy       "
# n = remove_and_strip(this, " is ")
# print(n)

# print(this)
# print(this.strip())

# def r_and_s(string, word):
#     newStr1 = string.replace(word, " ")  # removed the Word and replaced it with the spaces.
#     return newStr1.strip()

# nandu = "   Nandu is a Beauiful Girl    "
# n = r_and_s(nandu, " is ")
# print(n)

# Files
# f = open("The Beginning..!!\Files\poems.txt")
# a = f.read()
# if "are" in a:
#     print("Are is present")
# else:
#     print("Are is not present")
# f.close()

# returns and over write the score if its high from the previous one
# def game():
#     return 90

# score = game()
# with open("The Beginning..!!\Files\\hiscore.txt", "r") as f:
#     hiscore = int(f.read())

# if hiscore < score:
#     with open("The Beginning..!!\Files\\hiscore.txt", "w") as f:
#         f.write(str(score))

# Printing Tables
# for i in range(2,21):
#     with open(f"The Beginning..!!\Tables\Multiplication_Table_Of_{i}.txt", "w") as f:
#         for j in range(1,11):
#             f.write(f"{i} X {j} = {i*j}")
#             if j!= 10:
#                 f.write("\n")

# Replacing the words

# with open("The Beginning..!!\Files\sample.txt") as f:
#     content = f.read()
# content = content.replace("donkey", "$*$*$*$*$")
# with open("The Beginning..!!\Files\sample.txt", "w") as f:
#     f.write(content)
# words = ["mote", "kaddu", "bade"]
# with open("The Beginning..!!\Files\sample.txt") as f:
#     content = f.read()
# for word in words:
#     content = content.replace(word, "$*$*$*$*$")
#     with open("The Beginning..!!\Files\sample.txt", "w") as f:
#         f.write(content)

# Copying a File

# with open("The Beginning..!!\Files\\this.txt") as f:
#     content = f.read()
# with open("copy.txt", "w") as f:
#     f.write(content)

# Checing if files are identical..?

# file1 = "copy.txt"
# file2 = "The Beginning..!!\Files\\poems.txt"
# with open(file1) as f:
#     f1 = f.read()
# with open(file2) as f:
#     f2 = f.read()
# if f1 == f2:
#     print("They are identical")
# else:
#     print("They are not identical")

# Wiping out the whole File
# filename = "The Beginning..!!\Files\\poems.txt"
# with open(filename, "w")as f:
#     f.write(" ")

# Classes - OOPS
# class Programmer:
#     company = "Microsoft"
#     def __init__(self, name, product):
#         self.name = name
#         self.product = product

#     def getInfo(self):
#         print(f"The name of the Employee is {self.name}")
#         print(f"The Product used by {self.name} is {self.product}")

# tanish = Programmer("Tanish", "Skype")
# Nandu = Programmer("Nandu", "Github")
# tanish.getInfo()
# Nandu.getInfo()

# Calculating SquareRoot, Cube and Square
# class Calculator:
#     def __init__(self, num):
#         self.number = num

#     def square(self):
#         print(f"The Value of {self.number} Square is {self.number ** 2}")

#     def squareRoot(self):
#         print(f"The Value of {self.number} SquareRoot is {self.number ** .5}")

#     def cube(self):
#         print(f"The Value of {self.number} Cube is {self.number ** 3}")

# a = Calculator(9)
# a.square()
# a.squareRoot()
# a.cube()

# Train Reservation
# class Train:
#     def __init__(self, name, fare, seats ):
#         self.name  = name
#         self.fare  = fare
#         self.seats  = seats

#     def getStatus(self):
#         print("***********")
#         print(f"The Name of the Train is {self.name}")
#         print(f"Number of the seats available in this Train are {self.seats}")
#         print("***********")

#     def getFare(self):
#         print(f"The fare of Train {self.name} is Rs. {self.fare}")

#     def bookTicket(self):
#         if self.seats > 0:
#             print(f"Your Ticket has been booked ! Your seat number is {self.seats}")
#             self.seats = self.seats - 1
#         else:
#             print("Sorry! The Train is Full. Kindly try Tatkal")

# interCity = Train("Rajdhani Express: 140012", 90, 2)
# interCity.getStatus()
# interCity.bookTicket()
# interCity.bookTicket()
# interCity.bookTicket()
# interCity.getStatus()

# ******** OOPS ********
1.  # class C2dVec:
#     def __init__(self, i, j):
#         self.icap = i
#         self.jcap = j

#     def __str__(self):
#         return f"{self.icap}i + {self.jcap}j"

# class C3dVec(C2dVec):
#     def __init__(self, i, j, k):
#         super().__init__(i, j)
#         self.kcap = k

#     def __str__(self):
#         return f"{self.icap}i + {self.jcap}j + {self.kcap}k"

# v2d = C2dVec(1, 3)
# v3d = C3dVec(1, 9, 7)
# print(v2d)
# print(v3d)

2.
# class Animals:
#     animalType = "Mammal"

# class Pets:
#     color = "Green"

# class Dog:
#     @staticmethod
#     def bark():
#         print("Bow Bow")

# d = Dog()
# d.bark()

3.  # Incrementing Salary
# class Employee:
#     salary = 2000
#     increment = 1.5

#     @property
#     def salaryAfterIncrement(self):
#         return self.salary*self.increment

#     @salaryAfterIncrement.setter
#     def salaryAfterIncrement(self, sai):
#         self.increment = sai/self.salary

# e = Employee()
# print(e.salaryAfterIncrement )
# print(e.increment)
# e.salaryAfterIncrement = 1500
# print(e.increment)

4.
# class Complex:
#     def __init__(self, r, i):
#         self.real = r
#         self.imaginary = i

#     def __add__(self, c):
#         return Complex(self.real + c.real, self.imaginary + c.imaginary)

#     def __str__(self):
#         return f"{self.real} + {self.imaginary}i"

# c1 = Complex(1, 4)
# c2 = Complex(5, 8)
# print(c1 + c2)

# ********** Advanced Python Exercises**********
1.  # Enumerate Func
# l = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# for index, item in enumerate(l):
#     if index == 2 or index == 4 or index == 6:
#            print(index, item)
#         print(f"The {index + 1}th element is {item}")

2. #  Printing Multiplication Table using enu,eration func
# num = int(input("Enter a Number: "))
# table = [num * i for i in range(1, 11)]
# print(table)


3. 
# a = int(input("Enter a Number: "))
# b = int(input("Enter a Number: "))

# try:
#     print(a/b)
# except:
#     print("Infinite")

4. # Creating a new file and appending the user entered table in that File.
# num = int(input("Enter a Number: "))
# table = [num * i for i in range(1, 11) ]
# print(table, "\n")

# with open("The Beginning..!!\Files\\tables.txt", "w")as f:
#     f.write(str(table))
    # f.write("\n")
    

5. 
l = [str(i*7) for i in range(1,11)]
# print(l)

vertiTable = "\n".join(l)
print(vertiTable)