# a = 24
# if(a<12):
#    print("A is Greater than 12") 
# elif(a>23):
#    print("A is Greater than 23") 
# elif(a<12):
#    print("A is Smaller than 12") 
# else:
#     print("The data only is Wrong")


#Question.. Answers..
# sub1 = int(input("Enter First Subject Marks:\n"))
# sub2 = int(input("Enter Second Subject Marks:\n"))
# sub3 = int(input("Enter Third Subject Marks:\n"))


# if(sub1<33 or sub2<33 or sub3<33):
#     print("You are Fail..!!")

# elif(sub1+sub2+sub3)/3 <40:
#     print("You are fail due to less % less than 40..!!")
# else:
#     print("Congrtulations..!! You've passed the Test")



#Spam Detector
# text = input("Enter the text:\n")

# if("make a lot of money" in text):
#     spam = True
# elif("buy now" in text):
#     spam = True
# elif("click this" in text):
#     spam = True
# elif("subcsribe this" in text):
#     spam = True
# else:
#     spam = False

# if(spam):
#     print("Its a Spam..!!")
# else:
#     print("Its not a Spam..!!")


#Checking the Characters..!
# char = input("Enter the Charcters:\n")

# length = len(char)

# if(length<10):
#     print("It contains less than 10 Characters..!!")
# else:
#     print("It doesn't contain less than 10 Characters")



#Checking if names are der in or not..!!
# names = ["tanish","nandini", "mrunmayi", "aryan", "kashyap"]
# name = input("Enter your name:\n")

# if name in names:
#     print(f"{name} name is der..!!")
# else:
#     print(f"{name} name is not der..!!")




#Checking the Criteria..
# marks = int(input("Enter your marks:\n"))

# if marks >= 90:
#     grade = "Ex"
# elif marks >= 80:
#     grade = "A"
# elif marks >= 70:
#     grade = "B"
# elif marks >= 60:
#     grade = "C"
# elif marks >= 50:
#     grade = "D"
# else:
#     grade = "F"

# print(f"Your grade is {grade}")



# 5:14:30


