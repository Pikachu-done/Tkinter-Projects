from playsound import playsound
playsound("C:\\Users\\Admin\\Desktop\\Coding Languages\\Websites\\Spotify Clone\\songs\\4.mp3")
