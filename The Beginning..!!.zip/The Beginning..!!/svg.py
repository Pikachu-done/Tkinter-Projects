# a =  int(input("Enter a number: "))
# b =  int(input("Enter a number: "))

# print("The average is ",(a+b)/2)

# story = "Tanish is a Good Boy. \nHe \tis very Good."
# print(story)

# letter = '''Dear <|NAME|>
# You are Selected..

# Date: <|DATE|>
# '''

# name = input("Enter your Name: ")
# date = input("Enter Date: ")

# letter = letter.replace("<|NAME|>", name)
# letter = letter.replace("<|DATE|>", date)
# print(letter)


st = "This is  a String with  DoubleSpaces"

st = st.replace("  ", " ")
print(st)