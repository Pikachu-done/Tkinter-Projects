# greetings = "Good Morning, "
# name = "Tanish"
# c = greetings +  name
# print(c)

name = "PikachuIsTheBest"
# print(name[1])
# print(name[0:4])

print(name[0:10:3])