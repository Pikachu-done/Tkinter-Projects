# while(True):
#     print("Press q to Quit!")
#     a = input('Enter a Number: ')
#     if a == "q":
#         break

#     try:
#         a = int(a)
#         if a > 6:
#             print("You entered a number greater than 6")
#     except Exception as e:
#         print(f"You've resulted to an error of: {e}")

# print("Thank You for playing..!!")

# try:
#     i = int(input("Please Enter a Number: "))
#     c = 1/i

# except Exception as e:
#     print(e)
#     exit()

# finally:
#     print("We are Done..!")

# print("Thank You..!")


