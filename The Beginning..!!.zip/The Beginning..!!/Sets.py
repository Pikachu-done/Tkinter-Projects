# a = {1,2,3,4, 1}
# print(type(a))
# print(a)

# Questions.. Answers..
# num1 = int(input("Enter your Num1:\n"))
# num2 = int(input("Enter your Num2:\n"))
# num3 = int(input("Enter your Num3:\n"))
# num4 = int(input("Enter your Num4:\n"))
# num5 = int(input("Enter your Num5:\n"))

# s = {num1, num2, num3, num4, num5}
# print(s)


# Questions.. Answers..
# s = {18, "18"}
# print(s)



# Questions.. Answers..
s = {7, 8, "Tanish", (1,2)}
print(s)

