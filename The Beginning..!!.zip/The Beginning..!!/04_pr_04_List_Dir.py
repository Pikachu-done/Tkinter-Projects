# Author - Pikachu..
# Location - Gotham City..
# Date - 22/12/4044

import os
print(os.listdir())



