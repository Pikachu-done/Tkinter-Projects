string = "once there was  a Guy names Pikachu  who was very Kind to everyone in all ways"

# print(len(string))
# print(string.endswith("all"))
# print(string.count("a"))
# print(string.capitalize())
# print(string.find("Guy"))
# print(string.replace("Pikachu", "Tanish"))
print(string.replace("Pikachu", "Tanish"))
